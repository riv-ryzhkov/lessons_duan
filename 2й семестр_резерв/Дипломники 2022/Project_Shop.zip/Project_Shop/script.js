(function(){
  
  var cart = {items:[],total:''};
  
  var addToCart = function(product,qty){
    qty = qty || 1;
    var cart = getCart();
    var indexOfId = cart.items.findIndex(x => x.id == product.id);

    if(indexOfId === -1){
      cart.items.push(
        {
          id: product.id,
          name:product.name,
          price:product.price,
          qty: qty
        });      
    }else{
      cart.items[indexOfId].qty++;
    }
    
    updateCart(cart);
  }
  
  var getProductValues = function(element){
    var productId = $(element).parent().find('.my-cart-id').attr('id');
    var productName = $(element).parent().find('.my-cart-name').html();
    var productPrice = $(element).parent().find('.my-cart-price').html();
    return {id:productId,name:productName,price:productPrice};
  }
  
  $('.my-cart-add').on('click',function(){
    var product = getProductValues(this);
    addToCart({id:product.id,name:product.name,price:product.price});
  });
  
  var updateCart = function(cart){
     var totalCost = 0;
     var totalCount = 0;
    
     $('.shopping-cart-items').html('');
     for(var i =0; i < cart.items.length; i++){ 
       totalCost += (cart.items[i].qty * parseFloat(cart.items[i].price));
       totalCount += cart.items[i].qty;

       $('.shopping-cart-items').append(
         '<li class="clearfix">'+
         '<div class="my-cart-item">'+
         '<div><span>Товар: </span>'+cart.items[i].name+'</div>'+
         '<div><span>Цена: </span>  '+cart.items[i].price+' ₴ </div>'+
         '<div>Кол-ство: </span>'+
         '<i id="subtract-qty'+i+'" class="fa fa-minus-square update-qty subtract-qty" aria-hidden="true"></i><span> '+
         cart.items[i].qty+
         ' <i id="add-qty'+i+'" class="fa fa-plus-square update-qty add-qty" aria-hidden="true"></i></div>'+
         '</div>'+
         '<div class="my-cart-remove-container">'+
         '<i id="my-cart-remove'+i+'" class="fa fa-times my-cart-remove" aria-hidden="true">'+
         '</div>'+
         '</i>'
       );

       (function(){
         var currentIndex = i;
         $('#add-qty'+currentIndex).on('click',function(){
           updateQuantity(cart.items[currentIndex].id,++cart.items[currentIndex].qty);
         })
       })();

       (function(){
         var currentIndex = i;
         $('#subtract-qty'+currentIndex).on('click',function(){
           if(cart.items[currentIndex].qty != 1){           
             updateQuantity(cart.items[currentIndex].id,--cart.items[currentIndex].qty); 
           }
         });
       })();
       
       (function(){
         var currentIndex = i;
         $('#my-cart-remove'+currentIndex).on('click',function(){
           removeFromCart(cart.items[currentIndex].id);
         });
       })();
      }    
      updateCounter(totalCount);

      updateTotal(totalCost);
    }
  
  var updateQuantity = function(id,qty){
    var cart = getCart();
    var cartIndex = cart.items.findIndex(x => x.id == id);
    cart.items[cartIndex].qty = qty;
    updateCart(cart);
  };
  
  var removeFromCart = function(id){
    var cart = getCart();
    var cartIndex = cart.items.findIndex(x => x.id == id);
    
    cart.items.splice(cartIndex,1);
    updateCart(cart);
  };
  
  var getCart = function(){
    var myCart = cart;
      return myCart;
  }
   
  var updateCounter = function(val){
    $('.my-cart-counter').html(val);
  }
  
  var updateTotal = function(val){
    $('.my-cart-total').html(val.toFixed(2)+' ₴');
  }
  
  var checkout = function(){
    
  };
 
  $('button').click(function(e){
     e.preventDefault();
     $(".shopping-cart").fadeOut( "fast");  
  });
  
  $(".my-cart-icon").on("click", function(e) {
    e.stopPropagation();
    $(".shopping-cart").fadeToggle( "fast"); 
  });
  
  $('.my-cart-popup').on('click', function(e){
     e.stopPropagation();
  });  
})();

var pos = 0,
dpos = 3.5714,
cycle,
heart = false,
animating = false;

$('heart').click(function(){},function(){
  if(heart && !animating){
    $('heart').css('background-position','0 0');
    heart = false;
  }else if(!animating){
    animating = true;
    animate();
  }
});

function animate(){
  cycle = setInterval(increment,30);
}

function increment(){
  pos += dpos;
  if(pos > 100){
    clearInterval(cycle);
    heart = true;
    animating = false;
    pos = 0;
  }else{
    $('heart').css('background-position',pos+'% 0');
  }
}
