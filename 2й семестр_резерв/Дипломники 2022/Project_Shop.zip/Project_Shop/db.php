<?php
require "libs/rb.php";
R::setup( 'mysql:host=localhost;dbname=webusers',
    'root', 'root' );

session_start();


















