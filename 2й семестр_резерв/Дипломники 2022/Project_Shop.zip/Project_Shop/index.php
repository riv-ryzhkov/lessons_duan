<?php
require "db.php";
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
    <title>Web_main</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script>

        function openTab(evt, NameBrend) {
            var i, tabcontent, tablinks;

            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }

            tablinks = document.getElementsByClassName("tablinks");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }

            document.getElementById(NameBrend).style.display = "block";
            evt.currentTarget.className += " active";
        }

        window.onload = function () {
            document.body.classList.add('loaded_hiding');
            window.setTimeout(function () {
                document.body.classList.add('loaded');
                document.body.classList.remove('loaded_hiding');
            }, 500);
        }

        jQuery(function($) {
            $('#button').on('click', function(e) {
                $(e.currentTarget).attr('disabled', true);
                $('.loader').toggleClass('hide');
                setTimeout(function() {
                    $('.loader').toggleClass('hide');
                    $(e.currentTarget).attr('disabled', false);
                }, 2000)
            });
        });
        jQuery(function($) {
            $('#button2').on('click', function(e) {
                $(e.currentTarget).attr('disabled', true);
                $('.loader').toggleClass('hide');
                setTimeout(function() {
                    $('.loader').toggleClass('hide');
                    $(e.currentTarget).attr('disabled', false);
                }, 2000)
            });
        });
        jQuery(function($) {
            $('#button3').on('click', function(e) {
                $(e.currentTarget).attr('disabled', true);
                $('.loader').toggleClass('hide');
                setTimeout(function() {
                    $('.loader').toggleClass('hide');
                    $(e.currentTarget).attr('disabled', false);
                }, 2000)
            });
        });
        jQuery(function($) {
            $('#button4').on('click', function(e) {
                $(e.currentTarget).attr('disabled', true);
                $('.loader').toggleClass('hide');
                setTimeout(function() {
                    $('.loader').toggleClass('hide');
                    $(e.currentTarget).attr('disabled', false);
                }, 2000)
            });
        });
        jQuery(function($) {
            $('#button5').on('click', function(e) {
                $(e.currentTarget).attr('disabled', true);
                $('.loader').toggleClass('hide');
                setTimeout(function() {
                    $('.loader').toggleClass('hide');
                    $(e.currentTarget).attr('disabled', false);
                }, 2000)
            });
        });
        jQuery(function($) {
            $('#button6').on('click', function(e) {
                $(e.currentTarget).attr('disabled', true);
                $('.loader').toggleClass('hide');
                setTimeout(function() {
                    $('.loader').toggleClass('hide');
                    $(e.currentTarget).attr('disabled', false);
                }, 2000)
            });
        });

    </script>
</head>
<body bgcolor="#C4D7FD", link="red" vlink="#cecece" alink="#ff0000" bgcolor="black">
<?php if(isset($_SESSION['logged_user'])):?>
    Авторизован! Вы вошли на сайт интернет-магазин. Добро пожаловать! <?php echo $_SESSION['logged_user']->login; ?>!

<?php else: ?>
    <a href="/login.php"><font size="4">Вход</font></a>
    <a href="/signup.php"><font size="4">Регистрация</font></a>
<?php endif; ?>
<hr>
<div class="preloader">
    <svg class="preloader__image" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
        <path fill="currentColor"
              d="M304 48c0 26.51-21.49 48-48 48s-48-21.49-48-48 21.49-48 48-48 48 21.49 48 48zm-48 368c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48-21.49-48-48-48zm208-208c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48-21.49-48-48-48zM96 256c0-26.51-21.49-48-48-48S0 229.49 0 256s21.49 48 48 48 48-21.49 48-48zm12.922 99.078c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48c0-26.509-21.491-48-48-48zm294.156 0c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48c0-26.509-21.49-48-48-48zM108.922 60.922c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48-21.491-48-48-48z">
        </path>
    </svg>
</div>

<div class="preloader__item"></div>

<header class="gain-center">
    <div class="navbar">

        <p id="blink"><font size="6"><font color="blue"><svg xmlns="http://www.w3.org/2000/svg" width="41" height="41" fill="currentColor" class="bi bi-house-fill" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6zm5-.793V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
                        <path fill-rule="evenodd" d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z"/>
                    </svg></font><span style="padding: 0px 20px;">&nbsp;</span>Главная страница  </font>
            <a href="Contacts.html"><font size="4">КОНТАКТЫ | </font></a>
            <a href="News.html"><font size="4">НОВОСТИ | </font></a>
            <a href="Credit.html"><font size="4">КРЕДИТ | </font></a>
            <a href="OverviewNew.html"><font size="4">ОБЗОР НОВИНОК | </font></a>
            <a href="PaymentInfo.html"><font size="4">ОПЛАТА И ДОСТАВКА | </font></a>
            <a href="/logout.php">Выйти</a>
    </div>

</header>

<font size="5" color="#443FD9"><pre>       Каталог брендов       Смартфоны <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-phone" viewBox="0 0 16 16">
  <path d="M11 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h6zM5 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H5z"/>
  <path d="M8 14a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
</svg></pre>


    <div class="container my-cart-popup">
        <div class="shopping-cart">
            <div class="shopping-cart-header">
                <div class="shopping-cart-total">
                    <span class="lighter-text">Сумма платежа:</span>
                    <span class="main-color-text my-cart-total"></span>
                </div>
            </div>

            <ul class="shopping-cart-items">
                Корзина пуста...
            </ul>

            <a href="Pay.php" class="button my-cart-checkout">Оформить заказ</a>
        </div>
    </div>
    <content>

        <sidenav bgcolor="#FBFBEA">
            <div class="tab">

                <button id="button" class="tablinks" onclick="openTab(event, 'Samsung')"><font size="4">Samsung</font></button>
                <button id="button2" class="tablinks" onclick="openTab(event, 'Xiaomi')"><font size="4">Xiaomi</font></button>
                <button id="button3" class="tablinks" onclick="openTab(event, 'Apple')"><font size="4">Apple</font></button>
                <button id="button4" class="tablinks" onclick="openTab(event, 'Doogee')"><font size="4">Doogee</font></button>
                <button id="button5" class="tablinks" onclick="openTab(event, 'Nokia')"><font size="4">Nokia</font></button>
                <button id="button6" class="tablinks" onclick="openTab(event, 'Tecno')"><font size="4">Tecno</font></button>
            </div>
            <a href=""><font size="4"><a href="#" class="my-cart-icon">
                        <i class="fa fa-shopping-cart"></i>
                        <!-- cart -->
                        <div class="sticky">
                            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-cart4" viewBox="0 0 16 16">
                                <path d="M0 2.5A.5.5 0 0 1 .5 2H2a.5.5 0 0 1 .485.379L2.89 4H14.5a.5.5 0 0 1 .485.621l-1.5 6A.5.5 0 0 1 13 11H4a.5.5 0 0 1-.485-.379L1.61 3H.5a.5.5 0 0 1-.5-.5zM3.14 5l.5 2H5V5H3.14zM6 5v2h2V5H6zm3 0v2h2V5H9zm3 0v2h1.36l.5-2H12zm1.11 3H12v2h.61l.5-2zM11 8H9v2h2V8zM8 8H6v2h2V8zM5 8H3.89l.5 2H5V8zm0 5a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0zm9-1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0 "/>
                                <span class="badge my-cart-counter">0</span> </svg> </div>

                    </a>  </font></a>

        </sidenav>

        <container>

            <div class="loader hide"></div>
            <div id="Samsung" class="tabcontent">
                <table border="1" width="100%" height="100%">
                    <tr>
                        <!--Samsung    -->
                        <th>
                            <a href="">
                                <img src="picturesSg/S1.png" width="69%" height="64%" class="scale"></a><br>
                            <div id='product1' class='my-cart-name product my-cart-id'>Samsung Galaxy S21FE</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>21999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div> </th>

                        <th>
                            <a href="index.html">
                                <img src="picturesSg/S2.png" width="69%" height="66%" class="scale"></a><br>
                            <div id='product2' class='my-cart-name product my-cart-id'>Samsung Galaxy K21FE</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>22999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesSg/S3.png" width="69%" height="66%" class="scale"></a><br>
                            <div id='product3' class='my-cart-name product my-cart-id'>Samsung Galaxy S21</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>23999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesSg/S4.png" width="69%" height="66%" class="scale"></a><br>
                            <div id='product4' class='my-cart-name product my-cart-id'>Samsung Galaxy A03</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>8999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                    </tr>
                    <tr>

                        <th>
                            <a href="">
                                <img src="picturesSg/S5.png" width="69%" height="66%" class="scale"></a><br>
                            <div id='product5' class='my-cart-name product my-cart-id'>Samsung Galaxy A03 C</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>11999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesSg/S6.png" width="69%" height="66%" class="scale"></a><br>
                            <div id='product6' class='my-cart-name product my-cart-id'>Samsung Galaxy A12</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>4799 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesSg/S7.png" width="69%" height="66%" class="scale"></a><br>
                            <div id='product7' class='my-cart-name product my-cart-id'>Samsung Galaxy A12E</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>4499 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesSg/S8.png" width="69%" height="66%" class="scale"></a><br>
                            <div id='product8' class='my-cart-name product my-cart-id'>Samsung Galaxy A11</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>6899 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                    </tr>
                </table>
            </div>


            <div id="Xiaomi" class="tabcontent">
                <table border="1" width="100%" height="100%">
                    <tr>
                        <!--Xiaomi   -->
                        <th>
                            <a href="">
                                <img src="picturesXi/X1.png" width="69%" height="66%" class="scale"></a><br>
                            <div id='product9' class='my-cart-name product my-cart-id'>Xiaomi Poco X3 Pro 8</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>21999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button" class="mybtn">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesXi/X2.png" width="69%" height="66%" class="scale"></a><br>
                            <div id='product10' class='my-cart-name product my-cart-id'>Xiaomi 11 Lite 5G</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>22999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesXi/X3.png" width="69%" height="66%" class="scale"></a><br>
                            <div id='product11' class='my-cart-name product my-cart-id'>Xiaomi 11T 8/128Gb</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>23999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesXi/X4.png" width="69%" height="66%" class="scale"></a><br>
                            <div id='product12' class='my-cart-name product my-cart-id'>Xiaomi Redmi 9A</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>8999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>
                    </tr>
                    <tr>
                        <th>
                            <a href="">
                                <img src="picturesXi/X5.png" width="69%" height="66%" class="scale"></a><br>
                            <div id='product13' class='my-cart-name product my-cart-id'>Xiaomi 11 Lite 5G NE</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>21999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button" class="mybtn">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesXi/X6.png" width="69%" height="66%" class="scale"></a><br>
                            <div id='product14' class='my-cart-name product my-cart-id'>Xiaomi Redmi Note 10S</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>22999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesXi/X7.png" width="69%" height="66%" class="scale"></a><br>
                            <div id='product15' class='my-cart-name product my-cart-id'>Xiaomi 11T 8/256Gb</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>23999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesXi/X8.png" width="69%" height="66%" class="scale"></a><br>
                            <div id='product16' class='my-cart-name product my-cart-id'>Xiaomi 11 Lite 5G NE 8</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>8999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>
                    </tr>
                </table>
            </div>

            <div id="Apple" class="tabcontent">
                <table border="1" width="100%" height="100%">
                    <tr>
                        <!--Apple   -->
                        <th>
                            <a href="">
                                <img src="picturesAp/A1.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product17' class='my-cart-name product my-cart-id'>Apple iPhone 11 64Gb</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>33999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button" class="mybtn">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesAp/A2.png" width="69%" height="69%" class="scale"></a><br>
                            <div id='product18' class='my-cart-name product my-cart-id'>Apple iPhone 13Pro</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>29999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesAp/A3.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product19' class='my-cart-name product my-cart-id'>Apple iPhone 11 128Gb</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>23999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesAp/A4.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product20' class='my-cart-name product my-cart-id'>Apple iPhone 11 Pro 128Gb</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>26999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>
                    </tr>
                    <tr>

                        <th>
                            <a href="">
                                <img src="picturesAp/A5.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product21' class='my-cart-name product my-cart-id'>Apple iPhone 11 128Gb</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>31999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button" class="mybtn">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesAp/A6.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product22' class='my-cart-name product my-cart-id'>Apple iPhone 11 128Gb Black</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>32999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesAp/A7.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product23' class='my-cart-name product my-cart-id'>Apple iPhone 13 256Gb</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>23999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesAp/A8.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product24' class='my-cart-name product my-cart-id'>Apple iPhone 12 128Gb</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>20999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>
                    </tr>

                </table>

            </div>

            <div id="Doogee" class="tabcontent">
                <table border="1" width="100%" height="100%">
                    <tr>
                        <!--Doogee   -->
                        <th>
                            <a href="">
                                <img src="picturesDo/D1.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product25' class='my-cart-name product my-cart-id'>Doogee X96 Pro Black</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>3999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button" class="mybtn">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesDo/D2.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product26' class='my-cart-name product my-cart-id'>Doogee X96 Pro Blue</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>3599 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesDo/D3.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product27' class='my-cart-name product my-cart-id'>Doogee S68 Pro Black</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>7499 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesDo/D4.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product28' class='my-cart-name product my-cart-id'>Doogee S68 Pro Orange</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>7809 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>
                    </tr>
                </table>
            </div>

            <div id="Nokia" class="tabcontent">
                <table border="1" width="100%" height="100%">
                    <tr>
                        <!--Nokia   -->
                        <th>
                            <a href="">
                                <img src="picturesNk/N1.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product29' class='my-cart-name product my-cart-id'>Nokia G20 4/64Gb Night</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>2999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button" class="mybtn">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesNk/N2.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product30' class='my-cart-name product my-cart-id'>Nokia 1.4 2/32Gb Grey</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>3599 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesNk/N3.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product31' class='my-cart-name product my-cart-id'>Nokia 1.4 2/32Gb Blue</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>4499 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesNk/N4.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product32' class='my-cart-name product my-cart-id'>Nokia C30 2/32Gb Green</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>5809 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>
                    </tr>
                </table>
            </div>

            <div id="Tecno" class="tabcontent">
                <table border="1" width="100%" height="100%">
                    <tr>
                        <!--Tecno   -->
                        <th>
                            <a href="">
                                <img src="picturesTe/T1.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product33' class='my-cart-name product my-cart-id'>Tecno Camon 17P 6/128Gb</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>5999 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button" class="mybtn">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesTe/T2.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product34' class='my-cart-name product my-cart-id'>Tecno POP 4 (BC2c) 2/32Gb</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>2599 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesTe/T3.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product35' class='my-cart-name product my-cart-id'>Tecno Camon 17P 6/128Gb</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>5499 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>

                        <th>
                            <a href="">
                                <img src="picturesTe/T4.png" width="69%" height="60%" class="scale"></a><br>
                            <div id='product36' class='my-cart-name product my-cart-id'>Tecno POP 2F (B1G) 1/16GB</div><br>
                            <font color="#54230D"><span class='price my-cart-price'>1899 </span><span> ₴</span></font><br>
                            <div class='my-cart-add'><a href=""><button class="button">В коризну</button></a></div></th>
                    </tr>
                </table>
            </div>

        </container>

    </content>

    <footer>
        <p id="blink2"><font color="black"><span style="padding: 0px 20px;">&nbsp;</span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chat-square-dots-fill" viewBox="0 0 16 16">
                    <path d="M0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.5a1 1 0 0 0-.8.4l-1.9 2.533a1 1 0 0 1-1.6 0L5.3 12.4a1 1 0 0 0-.8-.4H2a2 2 0 0 1-2-2V2zm5 4a1 1 0 1 0-2 0 1 1 0 0 0 2 0zm4 0a1 1 0 1 0-2 0 1 1 0 0 0 2 0zm3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
                </svg></font>  <font size="5" color="black"> Подписывайся | Для получения новостей и акций <span style="padding: 0px 20px;">&nbsp;</span><span style="padding: 0px 20px;">&nbsp;</span></font>
            <input type="text" id="myInput" placeholder="Введите ваш Email">
            <span class="addBtn">Подписаться</span></p>
    </footer>
    <div class="pl">
        <p><font size="5"><span style="padding: 0px 20px;">&nbsp;</span>Присоединяйся!<span style="padding: 0px 20px;">&nbsp;</span></font><a href="https://web.telegram.org/z/"><font color="#5B6CF5"><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-telegram" viewBox="0 0 16 16">
                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.287 5.906c-.778.324-2.334.994-4.666 2.01-.378.15-.577.298-.595.442-.03.243.275.339.69.47l.175.055c.408.133.958.288 1.243.294.26.006.549-.1.868-.32 2.179-1.471 3.304-2.214 3.374-2.23.05-.012.12-.026.166.016.047.041.042.12.037.141-.03.129-1.227 1.241-1.846 1.817-.193.18-.33.307-.358.336a8.154 8.154 0 0 1-.188.186c-.38.366-.664.64.015 1.088.327.216.589.393.85.571.284.194.568.387.936.629.093.06.183.125.27.187.331.236.63.448.997.414.214-.02.435-.22.547-.82.265-1.417.786-4.486.906-5.751a1.426 1.426 0 0 0-.013-.315.337.337 0 0 0-.114-.217.526.526 0 0 0-.31-.093c-.3.005-.763.166-2.984 1.09z"/></svg></font>
            </a><span style="padding: 0px 20px;">&nbsp;
  </span>
            <a href="https://www.instagram.com"><font color="#F5CE5B"><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
                        <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334z"/>
                    </svg></font></a>
            <font color="red"><span style="padding: 0px 20px;">&nbsp;</span><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-youtube" viewBox="0 0 16 16">
                    <path d="M8.051 1.999h.089c.822.003 4.987.033 6.11.335a2.01 2.01 0 0 1 1.415 1.42c.101.38.172.883.22 1.402l.01.104.022.26.008.104c.065.914.073 1.77.074 1.957v.075c-.001.194-.01 1.108-.082 2.06l-.008.105-.009.104c-.05.572-.124 1.14-.235 1.558a2.007 2.007 0 0 1-1.415 1.42c-1.16.312-5.569.334-6.18.335h-.142c-.309 0-1.587-.006-2.927-.052l-.17-.006-.087-.004-.171-.007-.171-.007c-1.11-.049-2.167-.128-2.654-.26a2.007 2.007 0 0 1-1.415-1.419c-.111-.417-.185-.986-.235-1.558L.09 9.82l-.008-.104A31.4 31.4 0 0 1 0 7.68v-.123c.002-.215.01-.958.064-1.778l.007-.103.003-.052.008-.104.022-.26.01-.104c.048-.519.119-1.023.22-1.402a2.007 2.007 0 0 1 1.415-1.42c.487-.13 1.544-.21 2.654-.26l.17-.007.172-.006.086-.003.171-.007A99.788 99.788 0 0 1 7.858 2h.193zM6.4 5.209v4.818l4.157-2.408L6.4 5.209z"/>
                </svg></font>
            <font color="blue"><span style="padding: 0px 20px;">&nbsp;</span><svg xmlns="http://www.w3.org/2000/svg" width="35" height="35" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
                    <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"/>
                </svg></font></p></div>

    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script><script  src="./script.js"></script>
</font>
</body>
</html>







