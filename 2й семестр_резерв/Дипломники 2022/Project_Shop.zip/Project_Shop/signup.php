<?php
require "db.php";

$data = $_POST;
if(isset($data['do_signup'])){
    // Здесь регистрация

    $errors = array();
    if(trim($data['login']) == ''){
        $errors[] = 'Введите логин!';
    }
    if(trim($data['email']) == ''){
        $errors[] = 'Введите Email!';
    }
    if($data['password'] == ''){
        $errors[] = 'Введите пароль!';
    }
    if($data['password_2'] != $data['password']){
        $errors[] = 'Повторный пароль введен не верно!';
    }
    if(R::count('users',"login = ?", array(
            $data['login'])) > 0){
       $errors[] = 'Пользователь с таким логином уже существует!';
    }
    if(R::count('email',"login = ?", array(
            $data['email'])) > 0){
        $errors[] = 'Пользователь с таким email уже существует!';
    }

    if(empty($errors)){
        $user = R::dispense('users');
        $user->login = $data['login'];
        $user->email = $data['email'];
        $user->password = password_hash($data['password'],PASSWORD_DEFAULT);
        R::store($user);
        echo '<div style="color:green;">Вы успешно зарегистрированы!</div><hr>';
    }else {
        echo '<div style="color: red;">'.array_shift($errors).'</div><hr>';
    }
}
?>


<style>
    body {font-family: Arial, Helvetica, sans-serif;}
    * {box-sizing: border-box}

    input[type=text], input[type=password] {
        width: 100%;
        padding: 15px;
        margin: 5px 0 22px 0;
        display: inline-block;
        border: none;
        background: #f1f1f1;
    }

    input[type=text]:focus, input[type=password]:focus {
        background-color: #ddd;
        outline: none;
    }

    hr {
        border: 1px solid #f1f1f1;
        margin-bottom: 25px;
    }

    button {
        background-color: #4CAF50;
        color: white;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        cursor: pointer;
        width: 100%;
        opacity: 0.9;
    }

    button:hover {
        opacity:1;
    }

    .cancelbtn {
        padding: 14px 20px;
        background-color: #f44336;
    }

    .cancelbtn, .signupbtn {
        float: left;
        width: 50%;
    }

    .container {
        padding: 16px;
    }

    .clearfix::after {
        content: "";
        clear: both;
        display: table;
    }

    @media screen and (max-width: 300px) {
        .cancelbtn, .signupbtn {
            width: 100%;
        }
    }
</style>

<form action="/signup.php" method="POST">

    <div class="container">
        <h1>Форма регистрации</h1>
        <p>Пожалуйста, заполните эту форму, чтобы создать учетную запись.</p>
        <hr>

        <label for="login"><b>Логин</b></label>
        <input type="text" placeholder="Введите логин" name="login" value="<?php echo @$data['login']; ?>">

        <label for="email"><b>Email</b></label>
        <input type="text" placeholder="Введите ваш Email" name="email" value="<?php echo @$data['email']; ?>">

        <label for="psw"><b>Пароль</b></label>
        <input type="password" placeholder="Введите пароль" name="password" value="<?php echo @$data['password']; ?>">

        <label for="psw-repeat"><b>Повторить пароль</b></label>
        <input type="password" placeholder="Повторите пароль" name="password_2" value="<?php echo @$data['password_2']; ?>">

        <label>
            <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Запомнить меня
        </label>

        <div class="clearfix">
            <a href="index.php"><button type="button" class="cancelbtn">Вернуться</button></a>
            <button type="submit" class="signupbtn" name="do_signup">Зарегистрироваться</button>
        </div>
    </div>

</form>
