<?php
require "db.php";

$data = $_POST;

if ( isset($data['do_login']) ) {
    $errors = array();
    $user = R::findOne('users', 'login = ?', array($data['login']));
    if ( $user )
    {
        //логин существует
        if ( password_verify($data['password'], $user->password) )
        {
            //если пароль совпадает, то нужно авторизовать пользователя
            $_SESSION['logged_user'] = $user;
            echo '<div style="color:green;">Вы авторизованы!<br> 
            Можете перейти на <a href="/">главную</a> страницу.</div><hr>';
        }else
        {
            $errors[] = 'Неверно введен пароль!';
        }

    }else
    {
        $errors[] = 'Пользователь с таким логином не найден!';
    }

    if ( ! empty($errors) )
    {
        //выводим ошибки авторизации
        echo '<div id="errors" style="color:red;">' .array_shift($errors). '</div><hr>';
    }

    }
?>


<style>
    body {font-family: Arial, Helvetica, sans-serif;}
    form {border: 3px solid #f1f1f1;}

    input[type=text], input[type=password] {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 1px solid #ccc;
        box-sizing: border-box;
    }

    button {
        background-color: blue;
        color: white;
        padding: 14px 20px;
        margin: 12px 0;
        border: none;
        cursor: pointer;
        width: 100%;
    }

    button:hover {
        opacity: 0.8;
    }

    .cancelbtn {
        width: auto;
        padding: 10px 18px;
        background-color: #f44336;
    }

    .imgcontainer {
        text-align: center;
        margin: 24px 0 12px 0;
    }

    img.avatar {
        width: 40%;
        border-radius: 50%;
    }

    .container {
        padding: 16px;
    }

    span.psw {
        float: right;
        padding-top: 16px;
    }

    @media screen and (max-width: 300px) {
        span.psw {
            display: block;
            float: none;
        }
        .cancelbtn {
            width: 100%;
        }
    }
</style>

<form action="login.php" method="POST">

    <h2>Форма авторизации</h2>

        <div class="container">
            <label for="uname"><b>Логин:</b></label>
            <input type="text" placeholder="Введите логин" name="login" value="<?php echo @$data['login']; ?>">

            <label for="psw"><b>Пароль: </b></label>
            <input type="password" placeholder="Введите пароль" name="password" value="<?php echo @$data['password']; ?>">

            <button type="submit" name="do_login">Войти</button>
            <label>
                <input type="checkbox" checked="checked" name="remember"> Запомнить меня
            </label>
        </div>

        <div class="container" style="background-color:#f1f1f1">
            <a href="index.php"><button type="button" class="cancelbtn">Вернуться</button></a>
        </div>

</form>
